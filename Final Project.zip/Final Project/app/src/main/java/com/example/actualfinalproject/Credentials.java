package com.example.actualfinalproject;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Credentials {

    private String Username;
    private String Password;
    private ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();

    Credentials(String username, String password){
        this.Username = username;
        this.Password = password;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public void addBankAccount(BankAccount account){
        accounts.add(account);
    }

    public ArrayList<BankAccount> getAccounts() {
        return accounts;
    }
}
